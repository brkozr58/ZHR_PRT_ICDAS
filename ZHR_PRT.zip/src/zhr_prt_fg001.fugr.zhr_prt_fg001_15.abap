FUNCTION zhr_prt_fg001_15.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_SENDER) TYPE  AD_SMTPADR OPTIONAL
*"     VALUE(IV_TDNAME) TYPE  TDOBNAME
*"     VALUE(IT_EMAIL) TYPE  ZHR_PRT_TT023
*"     VALUE(T_PARAM) TYPE  ZHR_PRT_TT019
*"  EXPORTING
*"     VALUE(ET_RETURN) TYPE  ZHR_PRT_TRETURN
*"----------------------------------------------------------------------

  DATA : cx_req_bcs TYPE REF TO cx_send_req_bcs,
         cx_add_bcs TYPE REF TO cx_address_bcs,
         cx_doc_bcs TYPE REF TO cx_document_bcs,
         lv_text    TYPE string.

  DATA : document          TYPE REF TO cl_document_bcs,
         sent_to_all       TYPE os_boolean,
         send_request      TYPE REF TO cl_bcs,
         sender            TYPE REF TO if_sender_bcs,
         recipient         TYPE REF TO if_recipient_bcs,
         att_type          TYPE soodk-objtp VALUE 'HTM',
         l_receiver        TYPE comm_id_long,
         lv_subject        TYPE  string,
         l_cc              TYPE os_boolean,
         l_bcc             TYPE os_boolean,
         ls_return         TYPE bapireturn1,
         result            TYPE os_boolean,
         lt_lines          TYPE tlinetab,
         lv_dg(5)              ,
         lt_text           TYPE  bcsy_text,
         lt_split          TYPE TABLE OF char100,
         lv_char1000(1000) TYPE c.

  DATA langu LIKE sy-langu VALUE 'T'.
  SET LOCALE LANGUAGE  langu.

  PERFORM read_text TABLES lt_lines et_return USING iv_tdname .
  CHECK lt_lines IS NOT INITIAL .

  LOOP AT lt_lines ASSIGNING FIELD-SYMBOL(<fs>).
    REFRESH lt_split.
    LOOP AT t_param INTO DATA(s_param).
      lv_dg = '&' && CONV char2( sy-tabix ) && '&' .
      SEARCH <fs>-tdline  FOR lv_dg .
      IF sy-subrc EQ 0 .
        IF strlen( s_param-param ) GT 100.
          REPLACE ALL OCCURRENCES OF lv_dg IN <fs>-tdline WITH ' '.
          lv_char1000 = s_param-param.
          CALL FUNCTION 'RKD_WORD_WRAP'
            EXPORTING
              textline            = lv_char1000
              outputlen           = 100
            TABLES
              out_lines           = lt_split
            EXCEPTIONS
              outputlen_too_large = 1
              OTHERS              = 2.
          LOOP AT lt_split INTO DATA(ls_split) .
            DATA(lv_len) = strlen( ls_split ).
            SHIFT ls_split RIGHT DELETING TRAILING space.
            SHIFT ls_split LEFT DELETING LEADING space.
            APPEND ls_split(lv_len) TO lt_text.
          ENDLOOP.
        ELSE.
          REPLACE ALL OCCURRENCES OF lv_dg IN <fs>-tdline WITH s_param-param.
        ENDIF.
      ENDIF.
    ENDLOOP.
    IF lt_split[] IS INITIAL .
      APPEND CONV so_text255( <fs>-tdline ) TO lt_text.
    ENDIF.
  ENDLOOP.


  TRY.
      CALL METHOD cl_bcs=>create_persistent
        RECEIVING
          result = send_request.

      CALL METHOD send_request->encrypt
        RECEIVING
          result = result.

      lv_subject = lt_lines[ 1 ]-tdline.

      CALL METHOD send_request->set_message_subject
        EXPORTING
          ip_subject = CONV string( lv_subject ).

      CALL METHOD cl_document_bcs=>create_document
        EXPORTING
          i_type    = att_type
          i_subject = CONV so_obj_des( lv_subject )
          i_text    = lt_text
        RECEIVING
          result    = document.

      CALL METHOD send_request->set_document
        EXPORTING
          i_document = document.

      CALL METHOD cl_cam_address_bcs=>create_internet_address
        EXPORTING
          i_address_string = CONV #( iv_sender )
        RECEIVING
          result           = sender.
*
*      SELECT SINGLE usrid_long FROM pa0105 INTO l_receiver
*          WHERE pernr EQ iv_pernr
*            AND subty EQ 'MAIL'
*            AND begda LE sy-datum
*            AND endda GE sy-datum.
      LOOP AT it_email INTO DATA(ls_email).
        l_cc = l_bcc = ''.

        IF     ls_email-cc EQ 'X'.
          l_cc  = 'X'.
        ELSEIF ls_email-bc EQ 'X'.
          l_bcc = 'X'.
        ENDIF.
        l_receiver = ls_email-email.
        CALL METHOD cl_cam_address_bcs=>create_internet_address
          EXPORTING
            i_address_string = l_receiver
          RECEIVING
            result           = recipient.

        CALL METHOD send_request->add_recipient
          EXPORTING
            i_recipient  = recipient
            i_express    = 'X'
            i_copy       = l_cc
            i_blind_copy = l_bcc
            i_no_forward = 'X'.
      ENDLOOP.

      CALL METHOD send_request->set_send_immediately
        EXPORTING
          i_send_immediately = 'X'.

      CALL METHOD send_request->set_status_attributes
        EXPORTING
          i_requested_status = 'N'.

      CALL METHOD send_request->send
        EXPORTING
          i_with_error_screen = 'X'
        RECEIVING
          result              = sent_to_all.
      COMMIT WORK AND WAIT .
    CATCH cx_address_bcs INTO cx_add_bcs.
      lv_text = cx_add_bcs->get_text( ).
      ls_return-message = lv_text.
      ls_return-message_v1 = lv_text.
      PERFORM add_message TABLES et_return
                           USING space
                                 space
                                 'ZHR_PRT'
                                 'E'
                                 '000'
                                 ls_return .
  ENDTRY.


ENDFUNCTION.
